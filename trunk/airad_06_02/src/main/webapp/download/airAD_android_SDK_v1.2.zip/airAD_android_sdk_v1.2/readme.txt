﻿欢迎使用airAD sdk，开发者可以使用SDK在自己的android应用程序中嵌入airAD广告平台

关于 airAD android sdk v1.2 

目录结构介绍：
doc: 该文件夹内的文档详细介绍了如何在自己的程序中嵌入广告。
lib: 该文件夹内是需要导入到工程中的jar库。
sample: 该文件夹内是一个嵌入airAD平台的示例程序。
update log: 该文件是sdk版本更新的简单说明。

readme: 本文件

airAD!

详情请访问 http://www.airad.com