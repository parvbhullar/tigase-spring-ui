package com.airad.sample;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ShowResult extends Activity {

    private TextView text;
    private Button show;
    private static int select = 0;
    private Handler handler;
    private Timer timer;
    private int TEMP = R.drawable.bluestyle2;
    private int two = 0, four = 0, ten = 0;
    private Random rdm;
    private float random = 0.0f;
    private float sum = 0.0f;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        select = getIntent().getIntExtra("select", 0);

        setContentView(R.layout.show);

        rdm = new Random();

        text = (TextView) findViewById(R.id.showtext);
        show = (Button) findViewById(R.id.show);
        show.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (timer == null) {
                    sum = 0.0f;
                    doTimer();
                    text.setText("Make Your Choose");
                }
            }

        });
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);

                if (sum > random) {
                    if (timer != null) {
                        timer.cancel();
                        timer = null;
                    }
                    text.setText("Press To Restart");
                }
                else {
                    sum += 0.2;
                    show.setText(getShow());
                    if (TEMP == R.drawable.bluestyle2) {
                        show.setBackgroundResource(R.drawable.bluestyle3);
                        TEMP = R.drawable.bluestyle3;
                    }
                    else {
                        show.setBackgroundResource(R.drawable.bluestyle2);
                        TEMP = R.drawable.bluestyle2;
                    }
                }
            }
        };
        doTimer();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null)
            timer = null;
    }

    private void doTimer() {
        random = 5 + rdm.nextFloat() * 2;
        timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                handler.sendEmptyMessage(0);
            }

        }, 0, 200);
    }

    private String getShow() {
        switch (select) {
            case R.id.button1 : {
                if (two == 0) {
                    two = 1;
                    return "false";
                }
                else {
                    two = 0;
                    return "true";
                }
            }
            case R.id.button2 : {
                switch (four) {
                    case 0 : {
                        four++;
                        return "A";
                    }
                    case 1 : {
                        four++;
                        return "B";
                    }
                    case 2 : {
                        four++;
                        return "C";
                    }
                    case 3 : {
                        four = 0;
                        return "D";
                    }

                }
            }
            case R.id.button3 : {
                if (ten == 10)
                    ten = 0;
                return "" + ten++;
            }
            default :
                return "";
        }
    }

}
