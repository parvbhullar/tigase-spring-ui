//
//  airADSampleAppDelegate.h
//  airADSample
//
//  Created by NSXiu on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class airADSampleViewController;

@interface airADSampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    airADSampleViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet airADSampleViewController *viewController;

@end

