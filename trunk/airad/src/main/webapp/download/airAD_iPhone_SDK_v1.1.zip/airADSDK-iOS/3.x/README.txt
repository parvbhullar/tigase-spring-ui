关于  airAD iOS SDK 1.0版
---------------------------------------------
欢迎使用 airAD iOS SDK 1.1 版,这是airAD推出的第一款iOS SDK,主要作用是可以在你的App内部展示airAD制作的精良的广告,不仅能给你带来相应的广告收入,甚至可以为您带来更多的App下载量,因为我们做的广告,是终端用户所喜爱的广告.

广告本身将会展示在大小为 320×54 UIView中，你所需做的,是提供一个展示View的ViewController，你可以将他放置于你App的任何一个ViewController中，广告内容会滚动更新展示, 1.0版本中更新时间固定为20秒一次,暂时不能自定义.

你也可以实现AAKitViewDelegate (在AAKitViewProtocol.h文件中)，取得相关的详细系统提醒,以让我们的SDK可以更好的融合进App中.

包内文件
---------------------------------------------
iOS SDK
--README.txt //本文件
--SampleCode //示例代码
--AAKit //相关的主要文件

如何植入SDK
---------------------------------------------
(1) 添加iOS SDK以及相关的文件至你的工程中。这些文件都包含在airAD的文件夹中。总共包括如下文件：AAKitProtocol.h,AAKit.h,AAKitCommon.h,libAAKitSimulator.a,libAAKitDevice.a。(注意：Simulator和Device分别针对模拟器和实机。测试时可同时加入，在实际发布时，建议将Simulator去除。)

(2) 添加相关系统frameworks到你的项目，分别包括: 
	1. CoreLocation.framework
	2. Mapkit.framework
	3. CoreTelephony.framework(iOS >= 4.0)
    这些在编译时是需要的。

(3) 讲AAKit加入你的项目中,我们提供了相关的示例代码,你可以参考。以下是详细的说明：
	a. 在你想要加入的ViewController中加入如下代码：
	kit = [AAKit requestWithAppIdentifier:@"<#__Your_APP_ID_#>"]; //填入你从网站上获取的对应的APPID
	[kit setAdViewController:self]; 	//@Required,设置负责展示广告的ViewController
	[kit setDelegate:self]; 		//@Optional,设置对应的delegate,用以接收对应的Protocol中的方法

(4) 设置delegate后，可以得到许多对应的消息.具体请查看AAKitProtocol.h.

(5) 本SDK中已经含有SBJSON类用于对JSON数据进行解析.你可以直接加入我们附加提供的JSON文件,并直接使用.


更多帮助
---------------------------------------------
如果有任何疑问，可以联系support@airad.com获取帮助。
也可以加入airAD移动开发者群:

airAD--助你成为销量第一的APP
