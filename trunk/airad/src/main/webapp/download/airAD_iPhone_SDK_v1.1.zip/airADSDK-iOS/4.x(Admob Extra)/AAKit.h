//
//  AAKit.h
//  AAKitSample
//
//  Created by Xiu on 11-1-28.
//  Copyright 2011 南京米田科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AAKitCommon.h"


@interface AAKit : NSObject {
  
}

/**
 * 设置AAKit对应的delegate
 * 
 */
@property(assign) id delegate;

/**
 * 设置广告需要被添加到的ViewController
 * 
 */
@property(retain) UIViewController* adViewController;

/**
 * 设置每条请求之间的间隔时间，最短是10秒，最长是30秒.
 * 默认为5秒。
 */
@property(readwrite) int intervalDuration;

/**
 * 设置广告条出现位置，默认为AABannerBottom.
 *
 */
@property(copy) NSString* bannerContentMode;


/**
 * 设置广告条出现的动画状态
 *
 */
@property(copy) NSString* bannerAnimation;


/**
 * 设置当前App对应的代码.
 *
 */
@property(copy) NSString* appIdentifier;

/**
 *	通过此方法得到一个可用的AAkit的对象.
 * 附带参数:
 *									AppIdentifier:	当前App的代码
 */
+ (AAKit*) requestWithAppIdentifier:(NSString*)appId;

#pragma mark -
#pragma mark AdMob Extra Part

/**
 * 设置是否开启Admob SDK, 默认为NO
 *
 */
@property(readwrite) BOOL admobEnabled;

/**
 * 设置是否开启Admob SDK测试模式，默认为关闭。
 *
 */
@property(readwrite) BOOL admobTestEnabled;

/**
 * 设置Admob上的App对应的代码.
 *
 */
@property(copy) NSString* admobIdentifier;


@end
