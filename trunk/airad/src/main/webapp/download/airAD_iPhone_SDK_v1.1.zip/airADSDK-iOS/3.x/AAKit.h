//
//  AAKit.h
//  AAKitSample
//
//  Created by Xiu on 11-1-28.
//  Copyright 2011 南京米田科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AAKitCommon.h"
#import "AAKitProtocol.h"

@interface AAKit : NSObject {

}

/**
 * 设置AAKit对应的delegate
 * 
 */
@property(assign) id delegate;

/**
 * 设置广告需要被添加到的ViewController
 * 
 */
@property(retain) UIViewController* adViewController;

/**
 * 设置intervalDuration来确定每条请求之间的间隔时间，最短是5秒，最长是30秒.
 * 默认为5秒。
 */
@property(readwrite) int intervalDuration;

/**
 * 设置请求方式，默认为AABannerBottom.
 *
 */
//@property(copy) NSString* position;

/**
 * 设置当前App对应的代码.
 *
 */
@property(copy) NSString* appIdentifier;

/**
 *	通过此方法得到一个可用的AAkit的对象.
 * 附带参数:
 *									AppIdentifier:	当前App的代码
 */
+ (AAKit*) requestWithAppIdentifier:(NSString*)appId;


@end
