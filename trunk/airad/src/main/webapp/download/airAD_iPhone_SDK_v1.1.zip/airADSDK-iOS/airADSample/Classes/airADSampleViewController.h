//
//  airADSampleViewController.h
//  airADSample
//
//  Created by NSXiu on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AAKit.h"

@interface airADSampleViewController : UIViewController {
  AAKit* kit;
}

@end

