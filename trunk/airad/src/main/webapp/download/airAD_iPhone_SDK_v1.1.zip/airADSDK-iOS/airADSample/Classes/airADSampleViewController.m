//
//  airADSampleViewController.m
//  airADSample
//
//  Created by NSXiu on 4/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "airADSampleViewController.h"
 
@implementation airADSampleViewController

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
  kit = [AAKit requestWithAppIdentifier:AAKitIdentifierTest];//设置你从airad.com上得到的App ID,也可以使用现在的测试ID进行测试
  [kit setAdViewController:self]; 			//@Required
  [kit setBannerAnimation:kAABannerAnimationFixed]; // Optional
  [kit setDelegate:self]; 											//@Optional
  [kit setIntervalDuration:5.0]; 			 //@Optional
  [kit setBannerContentMode:kAABannerContentModeBottom]; //@Optional
  
  //Admob Extra part
  //  [kit setAdmobEnabled:YES]; //If Admob, @Required
  //  [kit setAdmobIdentifier:@"a14ce736a017301"]; //If Admob,@Required
  //  [kit setAdmobTestEnabled:YES]; //如果不是在国外，可以用AdmobTestEnabled为YES来测试Admob的广告
}

- (void)dealloc {
    [super dealloc];
}



@end
