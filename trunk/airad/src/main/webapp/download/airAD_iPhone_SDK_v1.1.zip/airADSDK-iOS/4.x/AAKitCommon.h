//
//  AAKitCommon.h
//  AAKitSample
//
//  Created by Xiu on 11-1-28.
//  Copyright 2011 南京米田科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>



#define AAKitIdentifierTest 								@"123456789"
#define AAParameterAppIdentifier 			@"AAParameterAppIdentifier"
#define AAParameterIntervalDuration @"AAParameterIntervalDuration"
#define AAParameterBannerMode 						@"AAParameterBannerMode"


extern NSString* const kAABannerContentModeBottom;
extern NSString* const kAABannerContentModeTop;


extern NSString* const kAABannerAnimationSlide; //Default
extern NSString* const kAABannerAnimationFixed;