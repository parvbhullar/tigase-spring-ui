//
//  AAKitProtocol.h
//  AAKitSample
//
//  Created by Xiu on 11-2-26.
//  Copyright 2011 南京米田科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AAKit.h"

@protocol AAKitViewDelegate


@optional
#pragma mark -
#pragma mark optional notification methods

/**
 * 当收到广告请求时发送;如果此时已经正确设置了对应的ViewController,
 * 那么会显示对应的广告牌.此时可适当调整当前界面布局,以不影响整体程序的使用.
 * 
 */
- (void) kitDidReceiveAd:(AAKit*)aakit;

/**
 * 当广告展示失败时发送;如果没有正确设置ViewController,则无法显示广告牌.
 * 失败后会在等待相应的等待时间后,继续发起下一次请求.
 */
- (void) kitDidFaildShowAd:(AAKit*)aakit;

/**
 * 当收到广告请求失败时发送;这是正常情况,当广告被播放完之后,会造成无广告播放的情况.
 * 失败后会在等待相应的等待时间后,继续发起下一次请求.
 */
- (void) kitDidFaildReceiveAd:(AAKit*)aakit;

/**
 * 在广告被点击后,将要进入全屏模式发送;此时由于广告被用户所点击,将会弹出全屏.程序相应应
 * 出对应的操作,以保证程序的正常运行,以及用户的正常使用.比如,如果游戏正在进行中,那么应该
 * 止游戏.
 * 
 */
- (void) kitWillPresentFullScreenFromAd:(AAKit*)aakit;

/**
 * 当广告完成全屏模式时发送;此时广告已经出现了全屏幕的状态,本地程序不会被看到.
 * 
 */
- (void) kitDidPresentFullScreenFromAd:(AAKit*)aakit;

/**
 * 当广告将要退出全屏模式时发送;此时广告已经出现了全屏幕的状
 * 
 */
- (void) kitWillDismissFullScreenFromAd:(AAKit*)aakit;

/**
 * 当广告将要退出全屏模式时发送;此时广告已经出现了全屏幕的状
 * 
 */
- (void) kitDidDismissFullScreenFromAd:(AAKit*)aakit;

#pragma mark -
#pragma mark Admob Extra Part

/**
 * 当切换至Admob的SDK时发送此消息
 * 
 */
- (void) kitDidSwitchToAdmob:(AAKit*)aakit;

/**
 * 当Admob收到广告时发送
 * 
 */
- (void) adMobDidReceiveAd:(AAKit*)aakit;


/**
 * 当Admob收到广告失败时发送
 * 
 */
- (void) adMobDidFailToReceiveAd:(AAKit*)aakit;

/**
 * 当Admob将要展示广告的时候发送
 * 
 */
- (void) adMobWillPresentFullScreenModalFromAd:(AAKit*)aakit;


/**
 * 当Admob将要结束展示广告的时候发送
 * 
 */
- (void) adMobWillDismissFullScreenModalFromAd:(AAKit*)aakit;

/**
 * 当Admob完成结束展示广告的时候发送
 * 
 */
- (void) adMobDidDismissFullScreenModalFromAd:(AAKit*)aakit;

/**
 * 当由于Admob的点击而要跳出广告的时候发送
 * 
 */
- (void) applicationWillTerminateFromAd:(AAKit*)aakit;

@end
